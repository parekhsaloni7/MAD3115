//
//  SceneTwoVC.swift
//  Mirror
//
//  Created by MacStudent on 2018-08-03.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import UIKit

class SceneTwoVC: UIViewController {

    
    @IBOutlet var txtName: UITextField!
    
    
    @IBOutlet var txtUserName: UITextField!
    
    
   @IBOutlet var txtPssword: UITextField!
    
    @IBAction func btnRegister(_ sender: Any) {
        
        print(String(describing: txtName.text))
        
        let nameAlert = UIAlertController(title: "User registration Details", message:( "USERNAME: \(txtName.text!)\nUSERID: \(txtUserName.text!)\nPASSWORD: \(txtPssword.text!)" ), preferredStyle: .actionSheet)
      //  let nameAlert1 = UIAlertController(title: "User registration Details", message: txtUserName.text, preferredStyle: .actionSheet)
        //let   nameAlert2 = UIAlertController(title: "User registration Details", message: txtPssword.text, preferredStyle: .actionSheet)
       
         nameAlert.addAction(UIAlertAction(title: "Dismiss", style: .cancel, handler: nil))
        
         self.present(nameAlert, animated: true)
    }
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
